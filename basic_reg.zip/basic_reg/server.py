from flask import Flask, render_template, request, redirect, session, flash
from mysqlconnection import connectToMySQL # imports the database info
app = Flask(__name__)
app.secret_key = 'mqQPb4Mh!'

@app.route('/')
def route_to_index():
    return render_template('index.html')

@app.route('/process', methods=['post'])
def process_reg_form():
    
    # if there are errors:
    is_valid = True
    if len(request.form['first_name']) < 1:
        is_valid = False
        # display error message
        flash("please enter first name")
    if len(request.form['last_name']) < 1:
        is_valid = False
        # display error message
        flash("please enter last name")
    if request.form['first_name'].replace(' ','',1).strip().isalpha() == False:
        print(request.form['first_name'].isalpha())
        is_valid = False
        # display error message
        flash("please use only letters in the first name text field")
    
    if request.form['last_name'].replace(' ','',1).strip().isalpha() == False:
        print(request.form['last_name'].isalpha())
        is_valid = False
        # display error message
        flash("please use only letters in the last name text field")

    if len(request.form['password']) < 1:
        is_valid = False
        # display error message
        flash("please enter a password")
    if len(request.form['password']) < 5:
        is_valid = False
        # display error message
        flash("your password needs to be at least 5 characters in length")
    if request.form['password'] != request.form['confirm_password']:
        is_valid = False
        # display error message
        flash("confirm password and password need to be the same")

    if is_valid:
        print(request.form)
        mysql = connectToMySQL('basic_reg') # call the function, passing in the name of our db
        # QUERY: INSERT INTO dojo_survey (name, location, language) 
        # VALUES (name from data, loc from data, occ from data);
        query = 'insert into registration (first_name, last_name, password) values (%(first_name)s, %(last_name)s, %(password)s);'
        data ={
            'first_name': request.form['first_name'],
            'last_name': request.form['last_name'],
            'password': request.form['password'],
        }
        print('response was true')
        flash("successfully added!")
        mysql.query_db(query, data)

    return  redirect('/')

if __name__ == "__main__":
    app.run(debug=True)